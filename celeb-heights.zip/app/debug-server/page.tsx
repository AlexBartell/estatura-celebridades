import { cookies } from 'next/headers';

export default function DebugServer() {
  const cookieStore = cookies();
  return (
    <pre>
      {JSON.stringify({
        typeof: typeof cookieStore,
        constructor: cookieStore?.constructor?.name,
        methods: Object.keys(cookieStore || {}),
        hasGet: typeof cookieStore.get === 'function',
      }, null, 2)}
    </pre>
  );
}
